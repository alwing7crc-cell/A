# seha-sa-

Netlify runs `npm run build` and publishes `dist/`. The preparation script copies
the HTML, styles, JavaScript, and image assets into a clean output directory and
fails if required source files are missing. Do not deploy the partial `dist/`
snapshot without preparing it first.

API handlers are deployed separately from `netlify/functions/` using the routes
in `netlify.toml`. Server code, data files, and source archives are not copied
into the public site.

Local development uses `netlify dev --port 8889`; the underlying static server
listens on port 3000 and never serves the repository root. Production APIs use
Netlify Functions and Netlify Database. Database migrations include an encrypted
snapshot of the two existing accounts and 45 medical records. Deployment applies
migrations automatically. Keep the configured encryption secret available for
all deployments that read these records.

Run `node --test tests/security.test.mjs` and `npx tsc --noEmit` for the security
regression checks and server type checks. Read SECURITY.md for access control,
key management, and post-deployment retirement of historical public stores.
