import { pgTable, text, timestamp, integer, index, check }  from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';
export const users = pgTable('secure_users', { id: text().primaryKey(), username: text().notNull().unique(), passwordHash: text('password_hash').notNull(), profile: text().notNull(), role: text().notNull() }, t => [check('secure_users_role_check', sql`${t.role} IN ('admin', 'doctor', 'user')`)]);
export const records = pgTable('secure_records', { id: text().primaryKey(), lookup: text().notNull(), payload: text().notNull(), ownerId: text('owner_id').references(() => users.id, {onDelete:'set null'}) }, t => [index('secure_records_lookup_idx').on(t.lookup), index('secure_records_owner_idx').on(t.ownerId)]);
export const sessions = pgTable('secure_sessions', { id: text().primaryKey(), userId: text('user_id').references(() => users.id, {onDelete:'cascade'}), csrf: text().notNull(), expires: timestamp({withTimezone:true}).notNull() });
export const limits = pgTable('security_limits', { id: text().primaryKey(), count: integer().notNull(), expires: timestamp({withTimezone:true}).notNull() });
