(function () {
  'use strict';

  const origin = 'https://www.seha.sa/#';
  const destinations = {
    '/': '/', '/home': '/', '/portal': '/',
    '/services': '/services', '/seha-plus': '/seha-plus',
    '/inquiries': '/inquiries', '/faq': '/faq',
    '/environmental-impact': '/environmental-impact',
    '/contactus': '/ContactUs', '/account/signup': '/account/signup',
    '/privacy-policy': '/privacy-policy', '/terms-of-use': '/terms-of-use'
  };
  const labels = {
    'الرئيسية': '/', 'الخدمات': '/services', 'صحة بلس': '/seha-plus',
    'الاستعلامات': '/inquiries', 'رجوع للاستعلامات': '/inquiries',
    'الرجوع للاستعلامات': '/inquiries', 'الأسئلة الشائعة': '/faq',
    'الأثر البيئي': '/environmental-impact', 'تواصل معنا': '/ContactUs',
    'إنشاء حساب': '/account/signup', 'انشاء حساب': '/account/signup'
  };

  function externalPath(path) {
    const key = path.split('?')[0].replace(/\/$/, '').toLowerCase() || '/';
    if (Object.prototype.hasOwnProperty.call(destinations, key)) return destinations[key];
    if (key.startsWith('/services/') || (key.startsWith('/inquiries/') && key !== '/inquiries/slenquiry')) return path;
    return null;
  }

  function destination(element) {
    const label = (element.textContent || '').trim().replace(/\s+/g, ' ');
    if (Object.prototype.hasOwnProperty.call(labels, label)) return origin + labels[label];
    if (element.tagName !== 'A') return null;
    const url = new URL(element.getAttribute('href') || '', location.href);
    if (url.origin !== location.origin) return null;
    const path = externalPath(url.hash.startsWith('#/') ? url.hash.slice(1) : url.pathname);
    return path === null ? null : origin + path;
  }

  function updateLinks() {
    document.querySelectorAll('a[href]').forEach(function (link) {
      const url = destination(link);
      if (url && link.getAttribute('href') !== url) link.setAttribute('href', url);
    });
  }

  // Capture clicks before the client router, including the inquiry back button.
  document.addEventListener('click', function (event) {
    const element = event.target.closest('a, button, [role="button"]');
    if (!element) return;
    const url = destination(element);
    if (!url) return;
    if (element.tagName === 'A' && (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || element.target === '_blank')) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    location.assign(url);
  }, true);

  function redirectRoute() {
    const hash = location.hash;
    // The bare site URL remains the sick-leave inquiry entry point.
    if (!hash && location.pathname === '/') return;
    const path = externalPath(hash.startsWith('#/') ? hash.slice(1) : location.pathname);
    if (path !== null) location.replace(origin + path);
  }
  window.addEventListener('hashchange', redirectRoute);
  window.addEventListener('popstate', redirectRoute);
  redirectRoute();
  document.addEventListener('DOMContentLoaded', function () {
    updateLinks();
    new MutationObserver(updateLinks).observe(document.body, {childList: true, subtree: true, attributes: true, attributeFilter: ['href']});
  });
})();
