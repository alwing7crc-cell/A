// Use the existing fixed accessibility control from the new footer shortcut.
document.addEventListener('click', (event) => {
  if (!event.target.closest('[data-open-accessibility]')) return;
  const control = document.querySelector('#seha-accessibility-trigger, #userwayAccessibilityIcon, .userway_buttons_wrapper button, .uwy .uai');
  if (control) control.click();
});
