(function () {
 'use strict';
 const nativeFetch=window.fetch.bind(window);
 let currentUser=null, csrf='', pending;
 async function refresh() {
  const response=await nativeFetch('/api/session',{credentials:'same-origin',cache:'no-store'});
  if(!response.ok){const error=await response.json().catch(()=>({}));throw Error(error.message||'تعذر بدء الجلسة، أعد المحاولة.');}
  const state=await response.json();csrf=state.csrf;currentUser=state.user;
  return state;
 }
 pending=refresh().catch(()=>{currentUser=null;});
 window.SiteSession={ready:()=>pending, user:()=>currentUser, refresh};
 window.fetch=async function(resource, options={}) {
  const url=new URL(typeof resource==='string'?resource:resource.url,location.href);
  if(url.origin!==location.origin)return nativeFetch(resource,options);
  const method=(options.method||(resource instanceof Request?resource.method:'GET')).toUpperCase();
  const protectedPath=/^\/(api\/|account\/|inquiry\.php|slenquiry\.php)/i.test(url.pathname);
  if(!protectedPath)return nativeFetch(resource,options);
  await pending;
  // Recover from a transient failure during the initial session request.
  if(!csrf)await refresh();
  const headers=new Headers(resource instanceof Request?resource.headers:undefined);
  new Headers(options.headers).forEach((v,k)=>headers.set(k,v));
  if(method!=='GET'&&method!=='HEAD')headers.set('X-CSRF-Token',csrf);
  const response=await nativeFetch(resource,{...options,headers,credentials:'same-origin',cache:'no-store'});
  if(/login/i.test(url.pathname)&&response.ok){await refresh();}
  if(response.status===401)currentUser=null;
  if(/logout/i.test(url.pathname)){currentUser=null;csrf='';}
  return response;
 };
 for(const k of ['JWTUserToken','seha_logged_in'])localStorage.removeItem(k);
 document.cookie='JWTUserToken=;path=/;max-age=0';
})();
