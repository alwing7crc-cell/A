// Loads the ElevenLabs chat widget right away (the <elevenlabs-convai> element is rendered by the app).
(function () {
  var s = document.createElement('script');
  s.src = 'https://unpkg.com/@elevenlabs/convai-widget-embed';
  s.async = true;
  document.head.appendChild(s);
})();
