CREATE TABLE "security_limits" (
	"id" text PRIMARY KEY,
	"count" integer NOT NULL,
	"expires" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "secure_records" (
	"id" text PRIMARY KEY,
	"lookup" text NOT NULL,
	"payload" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "secure_sessions" (
	"id" text PRIMARY KEY,
	"user_id" text,
	"csrf" text NOT NULL,
	"expires" timestamp with time zone NOT NULL
);
--> statement-breakpoint
CREATE TABLE "secure_users" (
	"id" text PRIMARY KEY,
	"username" text NOT NULL UNIQUE,
	"password_hash" text NOT NULL,
	"profile" text NOT NULL,
	"role" text NOT NULL
);
--> statement-breakpoint
ALTER TABLE "secure_sessions" ADD CONSTRAINT "secure_sessions_user_id_secure_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "secure_users"("id") ON DELETE CASCADE;