ALTER TABLE "secure_records" ADD COLUMN "owner_id" text;--> statement-breakpoint
CREATE INDEX "secure_records_lookup_idx" ON "secure_records" ("lookup");--> statement-breakpoint
CREATE INDEX "secure_records_owner_idx" ON "secure_records" ("owner_id");--> statement-breakpoint
ALTER TABLE "secure_records" ADD CONSTRAINT "secure_records_owner_id_secure_users_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "secure_users"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "secure_users" ADD CONSTRAINT "secure_users_role_check" CHECK ("role" IN ('admin', 'doctor', 'user'));