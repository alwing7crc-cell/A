-- Restores the administrator account with an Argon2id password hash; the display name falls back to the username.
INSERT INTO secure_users (id,username,password_hash,profile,role) VALUES ('ae26560f-d287-4fe7-a941-2852fcad58db','773875320','$argon2id$v=19$m=65536,t=3,p=4$KX3TtXzE/0BoUOuHDROAsQ$QvXgjzNdKKR0hr66H1oj7+XIL6Y0djDi52VEHJMZfmY','','admin')
ON CONFLICT (username) DO UPDATE SET password_hash=EXCLUDED.password_hash, profile=EXCLUDED.profile, role='admin';
