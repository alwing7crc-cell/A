import { randomBytes, randomUUID, createHash } from 'node:crypto';
import argon2 from 'argon2';
import { isDeepStrictEqual } from 'node:util';
import { getUser } from '@netlify/identity';
import { getStore } from '@netlify/blobs';
import { eq, and, gt, sql } from 'drizzle-orm';
import { database } from '../../db/index.js';
import { users, records, sessions, limits } from '../../db/schema.js';
import { encrypt, decrypt, digest, validateRecord, normalizeRecord, normalizeDigits } from '../../lib/crypto.mjs';
import { routeFor, readJsonBody, validOrigin } from '../../lib/request-security.mjs';

// Uses DATA_ENCRYPTION_KEY when configured; otherwise a random key is generated once and kept in a private Blobs store.
let cachedKey:Buffer|undefined;
async function loadKey(){
 if(cachedKey)return cachedKey;
 const configured=Netlify.env.get('DATA_ENCRYPTION_KEY');
 let hex=configured||'';
 if(!configured){
  const store=getStore({name:'security-keys',consistency:'strong'});
  hex=await store.get('data-encryption-key',{type:'text'})||'';
  if(!hex){await store.set('data-encryption-key',randomBytes(32).toString('hex'),{onlyIfNew:true});hex=await store.get('data-encryption-key',{type:'text'})||'';}
 }
 if(!/^[a-f0-9]{64}$/i.test(hex))throw new Error('Invalid encryption configuration');
 const key=Buffer.from(hex,'hex');
 if(key.length===32)cachedKey=key;
 return key;
}

// Rows encrypted with a key that is no longer available are skipped instead of breaking every request.
const tryDecrypt=(value:string,key:Buffer)=>{try{return decrypt(value,key);}catch{return null;}};
const profileName=(u:any,key:Buffer)=>tryDecrypt(u.profile,key)?.name||u.username;

export default async function handler(req: Request, context: any) {
 const json=(v:any,status=200,extra:any={})=>Response.json(v,{status,headers:{'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Strict-Transport-Security':'max-age=31536000; includeSubDomains','Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'",...extra}});
 const fail=(status:number,message:string)=>json({success:false,errorCode:100,errorMessage:message,message},status);
 try {
 const url=new URL(req.url), path=url.pathname.toLowerCase(), method=req.method;
 const route=routeFor(path);
 if(!route)return fail(404,'المسار غير موجود');
 if(!route.methods.includes(method))return fail(405,'طريقة غير مسموحة');
 const key=await loadKey();
 if(key.length!==32)return fail(503,'الخدمة غير مهيأة حالياً. يرجى التواصل مع مسؤول الموقع لاستعادة إعدادات حماية البيانات.');
 const db=database();
 if(!['GET','POST','PUT','DELETE'].includes(method))return fail(405,'طريقة غير مسموحة');
 const write=method!=='GET';
 if(write && !validOrigin(req))return fail(403,'طلب غير مصرح');
 const now=new Date();
 const category=route.kind==='login'?'login':route.kind==='inquiry'?'inquiry':'api';
 const bucket=Math.floor(Date.now()/600000);
 const lid=digest(`${context.ip||'unknown'}|${category}|${bucket}`,key);
 const [limit]=await db.insert(limits).values({id:lid,count:1,expires:new Date(Date.now()+1200000)}).onConflictDoUpdate({target:limits.id,set:{count:sql`${limits.count}+1`}}).returning();
 if(limit.count>(category==='login'?10:category==='inquiry'?30:200))return json({errorCode:100,message:'محاولات كثيرة، حاول لاحقاً'},429,{'Retry-After':'600'});
 const sid=context.cookies.get('__Host-seha_session');
 const hashed=sid?createHash('sha256').update(sid).digest('hex'):'';
 let [session]=hashed&&route.kind!=='inquiry'?await db.select().from(sessions).where(and(eq(sessions.id,hashed),gt(sessions.expires,now))):[];
 const newSession=async(userId:string|null)=>{
  if(session)await db.delete(sessions).where(eq(sessions.id,session.id));
  const token=randomBytes(32).toString('hex'), csrf=randomBytes(32).toString('hex');
  await db.insert(sessions).values({id:createHash('sha256').update(token).digest('hex'),userId,csrf,expires:new Date(Date.now()+3600000)});
  context.cookies.set({name:'__Host-seha_session',value:token,path:'/',httpOnly:true,secure:true,sameSite:'strict',maxAge:3600});
  return csrf;
 };
 let [user]=session?.userId?await db.select().from(users).where(eq(users.id,session.userId)):[];
 if(route.kind==='session'){
  if(method!=='GET')return fail(405,'طريقة غير مسموحة');
  const csrf=session?.csrf||await newSession(null);
  return json({csrf,user:user?{username:user.username,role:user.role,name:profileName(user,key)}:null});
 }
 if(write && (!session||req.headers.get('x-csrf-token')!==session.csrf))return fail(403,'انتهت الجلسة، أعد المحاولة');
 let body:any={};
 if(write&&method!=='DELETE'&&route.kind!=='logout'){
  try{body=await readJsonBody(req);}catch(error:any){return fail(error.status||400,'بيانات الطلب غير صالحة');}
 }
 if(route.kind==='login'){
  if(method!=='POST')return fail(405,'طريقة غير مسموحة');
  const username=body.Username,password=body.Password;
  if(typeof username!=='string'||typeof password!=='string'||!username.trim()||username.length>100||!password||password.length>256)return fail(400,'بيانات غير صالحة');
  // Account-wide limits also stop guessing distributed across multiple IP addresses.
  const accountLimitId=digest(`account|${username.trim()}|${bucket}`,key);
  const [accountLimit]=await db.insert(limits).values({id:accountLimitId,count:1,expires:new Date(Date.now()+1200000)}).onConflictDoUpdate({target:limits.id,set:{count:sql`${limits.count}+1`}}).returning();
  if(accountLimit.count>20)return json({errorCode:100,message:'محاولات كثيرة، حاول لاحقاً'},429,{'Retry-After':'600'});
  const [candidate]=await db.select().from(users).where(eq(users.username,username.trim()));
  // Dummy hash verification avoids revealing whether an account exists through timing.
  const hash=candidate?.passwordHash || '$argon2id$v=19$m=65536,t=3,p=4$w6ZCTqYW3pNd5bcvlh4xFg$vwQHFrTZvXLZ1Afy0dVaEwC7pVxqaj5vBxk9i2mIeRo';
  if(!await argon2.verify(hash,password)||!candidate)return fail(401,'بيانات الدخول غير صحيحة');
  const csrf=await newSession(candidate.id);
  return json({errorCode:0,data:{sendVerificationCode:false,userRole:[{RoleId:1,RoleName:candidate.role}],userName:candidate.username,name:profileName(candidate,key)},csrf});
 }
 if(route.kind==='logout'){if(method!=='POST')return fail(405,'طريقة غير مسموحة');if(session)await db.delete(sessions).where(eq(sessions.id,session.id));context.cookies.set({name:'__Host-seha_session',value:'',path:'/',httpOnly:true,secure:true,sameSite:'strict',maxAge:0});return json({success:true});}
 if(route.kind==='inquiry'){
  if(method!=='GET')return fail(405,'طريقة غير مسموحة');
  const patient=normalizeDigits(url.searchParams.get('PatientId')||url.searchParams.get('id')||url.searchParams.get('IDNumber')||'').trim();
  const code=normalizeDigits(url.searchParams.get('NormalizedServiceCode')||url.searchParams.get('code')||url.searchParams.get('LeaveId')||'').toLowerCase().trim();
  if(!/^\d{10}$/.test(patient)||! /^[a-z0-9-]{3,40}$/.test(code))return fail(400,'رقم الهوية ورمز الخدمة مطلوبان');
  const found=await db.select({payload:records.payload}).from(records).where(eq(records.lookup,digest(patient+'|'+code,key))).limit(1);
  return json(found.map(r=>tryDecrypt(r.payload,key)).filter(Boolean).map((p:any)=>{delete p.Notes;return p;}));
 }
 // Identity users are admitted only when explicitly linked to an existing application account.
 if(!user){const identity=await getUser();if(identity){const [linked]=await db.select().from(users).where(eq(users.id,identity.id));user=linked;}}
 if(!user)return fail(401,'يرجى تسجيل الدخول');
 if(route.kind==='users'){
  if(user.role!=='admin')return fail(403,'صلاحيات غير كافية');
  const target=decodeURIComponent(url.pathname.split('/').pop()||'');
  if(method==='GET'){const all=await db.select().from(users);return json({success:true,data:all.map(u=>({username:u.username,role:u.role,name:profileName(u,key)}))});}
  const username=method==='PUT'?body.newUsername:body.username, password=method==='PUT'?body.newPassword:body.password;
  if(method==='DELETE'){
   const [victim]=await db.select().from(users).where(eq(users.username,target));
   if(!victim)return fail(404,'المستخدم غير موجود');
   if(victim.id===user.id||victim.role==='admin')return fail(403,'لا يمكن حذف حساب الإدارة');
   await db.delete(users).where(eq(users.id,victim.id));return json({success:true});
  }
  if(typeof username!=='string'||! /^[a-zA-Z0-9@._-]{3,100}$/.test(username)||typeof password!=='string'||password.length<12||password.length>128)return fail(400,'استخدم اسم مستخدم صالح وكلمة مرور من 12 إلى 128 حرفاً');
  const hash=await argon2.hash(password,{type:argon2.argon2id});
  if(method==='POST'){
   if(typeof body.name!=='string'||body.name.length>100||/[<>]/.test(body.name))return fail(400,'اسم غير صالح');
   await db.insert(users).values({id:randomUUID(),username,passwordHash:hash,profile:encrypt({name:body.name},key),role:'doctor'});
  }else if(method==='PUT'){
   if(target!==user.username)return fail(403,'يمكن تعديل حسابك فقط');
   await db.update(users).set({username,passwordHash:hash}).where(eq(users.id,user.id));
   await db.delete(sessions).where(eq(sessions.userId,user.id));
  }else return fail(405,'طريقة غير مسموحة');
  return json({success:true});
 }
 if(route.kind==='records'){
  if(!['admin','doctor'].includes(user.role))return fail(403,'صلاحيات غير كافية');
  if(path.includes('sync')||url.searchParams.has('sync'))return fail(410,'تم إيقاف المزامنة القديمة');
  if(method==='GET'){const rows=await db.select().from(records).where(user.role==='admin'?undefined:eq(records.ownerId,user.id));return json({success:true,...(()=>{const data=rows.map(r=>tryDecrypt(r.payload,key)).filter(Boolean);return {count:data.length,data};})()});}
  const id=decodeURIComponent(url.pathname.split('/').pop()||'').toLowerCase();
  if(method==='DELETE'){const removed=await db.delete(records).where(and(eq(records.id,id),user.role==='admin'?undefined:eq(records.ownerId,user.id))).returning({id:records.id});if(!removed.length)return fail(404,'التقرير غير موجود');return json({success:true});}
  body=normalizeRecord(body);
  try{validateRecord(body);}catch(error:any){return fail(400,error.message==='invalid'?'أحد حقول التقرير يحتوي على نص غير مسموح أو يتجاوز الطول المسموح':error.message);}
  const code=body.NormalizedServiceCode.toLowerCase();
  if(method==='PUT'&&!/^[a-z0-9-]{3,40}$/.test(id))return fail(400,'معرف غير صالح');
  const entry={id:code,ownerId:user.id,lookup:digest(body.PatientId+'|'+code,key),payload:encrypt(body,key)};
  if(method==='POST'){
   const inserted=await db.insert(records).values(entry).onConflictDoNothing({target:records.id}).returning({id:records.id});
   if(!inserted.length){
    // A lost mobile response can lead to the same submission being sent again.
    const [existing]=await db.select({ownerId:records.ownerId,payload:records.payload}).from(records).where(eq(records.id,code));
    if(!existing||existing.ownerId!==user.id||!isDeepStrictEqual(tryDecrypt(existing.payload,key),body))return fail(409,'رمز الخدمة مستخدم بالفعل، اختر رمزاً آخر');
   }
  }
  else if(method==='PUT'){const updated=await db.update(records).set({id:code,lookup:entry.lookup,payload:entry.payload}).where(and(eq(records.id,id),user.role==='admin'?undefined:eq(records.ownerId,user.id))).returning({id:records.id});if(!updated.length)return fail(404,'التقرير غير موجود');}
  else return fail(405,'طريقة غير مسموحة');
  return json({success:true,data:body});
 }
 return fail(404,'المسار غير موجود');
 }catch(error:any){return fail(error?.code==='23505'?409:503,error?.code==='23505'?'البيانات موجودة بالفعل':'تعذر إتمام الطلب، حاول لاحقاً');}
}
export const config={path:['/api/*','/account/loginv3','/Account/loginv3','/Account/Logout','/account/logout','/inquiry.php','/slenquiry.php']};
