import { lt } from 'drizzle-orm';
import { database } from '../../db/index.js';
import { sessions, limits } from '../../db/schema.js';
export default async () => {
 const db=database(), now=new Date();
 await db.delete(sessions).where(lt(sessions.expires,now));
 await db.delete(limits).where(lt(limits.expires,now));
};
export const config={schedule:'@daily'};
