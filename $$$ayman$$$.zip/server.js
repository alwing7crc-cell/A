import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.disable('x-powered-by');
app.use((req,res,next)=>{
 res.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer'});
 next();
});
app.use(['/api','/account','/Account','/.netlify'],(_req,res)=>res.status(503).json({message:'Use Netlify dev on port 8889 for server functions.'}));
for(const dir of ['js','css','assets','images','img']) app.use('/'+dir,express.static(path.join(root,dir),{dotfiles:'deny',fallthrough:false}));
app.get('/.well-known/security.txt',(_req,res)=>res.type('text/plain').sendFile(path.join(root,'.well-known','security.txt'),{dotfiles:'allow'}));
app.get('/googledbcfb73b6979be60.html',(_req,res)=>res.sendFile(path.join(root,'googledbcfb73b6979be60.html')));
app.get('/{*path}',(_req,res)=>res.sendFile(path.join(root,'index.html')));
app.listen(3000,'127.0.0.1');
