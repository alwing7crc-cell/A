import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { encrypt,decrypt,digest,validateRecord,normalizeRecord,normalizeDigits } from '../lib/crypto.mjs';
import {readFileSync} from 'node:fs';
import {routeFor, readJsonBody, validOrigin} from '../lib/request-security.mjs';
test('public handlers match only explicit routes and enforce allowed methods',()=>{
 assert.equal(routeFor('/api/users/login').kind,'login');
 assert.equal(routeFor('/api/inquiry').kind,'inquiry');
 assert.equal(routeFor('/slenquiry.php').kind,'inquiry');
 assert.equal(routeFor('/api/sick-leaves/inquiry').kind,'records');
 assert.equal(routeFor('/api/users/not-login').kind,'users');
 assert.equal(routeFor('/api/private/login'),null);
 assert.equal(routeFor('/api/private/inquiry'),null);
 assert.deepEqual(routeFor('/api/users/admin').methods,['PUT','DELETE']);
 assert.deepEqual(routeFor('/api/sick-leaves').methods,['GET','POST']);
});
test('write origin checks reject sibling domains, missing origins and cross-site requests',()=>{
 const req=headers=>new Request('https://example.test/api/users',{method:'POST',headers});
 assert.equal(validOrigin(req({origin:'https://example.test','sec-fetch-site':'same-origin'})),true);
 for(const headers of [{},{origin:'https://evil.test'},{origin:'https://example.test','sec-fetch-site':'cross-site'},{origin:'https://example.test','sec-fetch-site':'same-site'}])assert.equal(validOrigin(req(headers)),false);
});
test('JSON parsing limits streamed bytes and rejects invalid bodies and content types',async()=>{
 const req=(body,headers={'content-type':'application/json'})=>new Request('https://example.test',{method:'POST',headers,body});
 assert.deepEqual(await readJsonBody(req('{"name":"اسم"}')),{name:'اسم'});
 for(const body of ['null','[]','"text"','{'])await assert.rejects(readJsonBody(req(body)),{status:400});
 await assert.rejects(readJsonBody(req('{}',{'content-type':'text/plain'})),{status:415});
 await assert.rejects(readJsonBody(req('{}',{'content-type':'application/json','content-length':'50000'})),{status:413});
 // Multi-byte input must be limited in bytes even with no declared length.
 await assert.rejects(readJsonBody(req(JSON.stringify({name:'م'.repeat(17000)}))),{status:413});
});
test('health encryption uses fresh nonces, authenticates ciphertext and key',()=>{
 const key=randomBytes(32),value={PatientName:'مريض'};
 const a=encrypt(value,key),b=encrypt(value,key);assert.notEqual(a,b);assert.deepEqual(decrypt(a,key),value);
 const tampered=Buffer.from(a,'base64');tampered[30]^=1;
 assert.throws(()=>decrypt(tampered.toString('base64'),key));assert.throws(()=>decrypt(a,randomBytes(32)));
 assert.notEqual(digest('123|code',key),digest('124|code',key));
});
test('record validation rejects injection, oversized fields and missing lookup factors',()=>{
 const good={PatientId:'1234567890',NormalizedServiceCode:'GSL123456789012',PatientName:'اسم المريض'};
 assert.deepEqual(validateRecord(good),good);
 for(const patch of [{PatientId:''},{PatientId:1234567890},{NormalizedServiceCode:12345},{NormalizedServiceCode:''},{constructor:'injected'},{PatientName:'<img src=x onerror=alert(1)>'},{PatientName:'x'.repeat(2001)},{Notes:{evil:true}},{From:'invalid'}])assert.throws(()=>validateRecord({...good,...patch}));
});
test('public client cannot fall back to external health storage or fixed credentials',()=>{
 for(const file of ['index.html','js/seha-dashboard-app.js','js/security-session.js']){
 const text=readFileSync(new URL('../'+file,import.meta.url),'utf8');assert.ok(!text.includes('kvdb.io'));assert.ok(!text.includes('seha_token_'));
 }
 const bundle=readFileSync(new URL('../js/index-mG2x8W2Z.js',import.meta.url),'utf8');assert.ok(!bundle.includes('Ie.trim()==="admin"'));
});

test('browser requests use server session CSRF and never promote failed logins',async()=>{
 const {JSDOM}=await import('jsdom');
 const dom=new JSDOM('',{url:'https://example.test',runScripts:'outside-only'});
 const w=dom.window;w.Request=Request;w.Headers=Headers;
 const calls=[];let loggedIn=false;
 w.fetch=async(url,options={})=>{
  calls.push({url,options});
  if(url==='/api/session')return Response.json({csrf:loggedIn?'rotated-token':'initial-token',user:loggedIn?{username:'doctor',role:'doctor'}:null});
  if(url==='/api/users/login') {const good=JSON.parse(options.body).Password==='correct';if(good)loggedIn=true;return Response.json({errorCode:good?0:100},{status:good?200:401});}
  return Response.json({success:true});
 };
 w.localStorage.setItem('seha_logged_in','true');
 w.eval(readFileSync(new URL('../js/security-session.js',import.meta.url),'utf8'));
 await w.SiteSession.ready();assert.equal(w.SiteSession.user(),null);assert.equal(w.localStorage.getItem('seha_logged_in'),null);
 await w.fetch('/api/users/login',{method:'POST',body:JSON.stringify({Password:'wrong'})});assert.equal(w.SiteSession.user(),null);
 await w.fetch('/api/users/login',{method:'POST',body:JSON.stringify({Password:'correct'})});assert.equal(w.SiteSession.user().username,'doctor');
 await w.fetch('/api/sick-leaves',{method:'POST',body:'{}'});
 const last=calls.at(-1);assert.equal(last.options.headers.get('X-CSRF-Token'),'rotated-token');assert.equal(last.options.credentials,'same-origin');
 dom.window.close();
});


test('mobile report payload accepts Arabic and Persian digits while retaining validation',()=>{
 const mobile={id:'1794123456789',PatientId:'١٢٣٤٥٦٧٨٩٠',NormalizedServiceCode:' GSL۱۲۳۴۵۶ ',PatientName:'اسم المريض',From:'2026-11-08',To:'2026-11-08',SickLeaveDate:'2026-11-08',Duration:'١',Hospital:'مستشفى الملك خالد',OrganizationName:'مستشفى الملك خالد',DoctorName:'أيمن',"Doctor NAME":'أيمن',JobTitle:'طبيب',Status:'approved',Notes:''};
 const normalized=normalizeRecord(mobile);
 assert.equal(normalized.PatientId,'1234567890');
 assert.equal(normalized.NormalizedServiceCode,'GSL123456');
 assert.equal(normalized.Duration,1);
 assert.equal(validateRecord(normalized),normalized);
 assert.equal(normalizeDigits('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹'),'01234567890123456789');
 assert.equal(validateRecord({...normalized,isCompanion:true,type:'companion',CompanionName:'اسم المرافق','Patient Name':'اسم المرافق',Relationship:1,RelationshipName:'أم',RelationshipText:'أم'}).isCompanion,true);
 for(const patch of [{PatientId:'١٢٣'},{From:'2026-02-30'},{To:'2026-11-07'},{Duration:'٠'},{Notes:'<script>'}])assert.throws(()=>validateRecord(normalizeRecord({...mobile,...patch})));
});
